-- Create databases for each microservice
CREATE DATABASE kala_kriti_users;
CREATE DATABASE kala_kriti_products;
CREATE DATABASE kala_kriti_orders;
CREATE DATABASE kala_kriti_payments;
